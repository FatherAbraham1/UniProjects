/*    */ package de.uni_leipzig.asv.toolbox.jLanI.kernel;
/*    */ 
/*    */ public class RequestException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 3762253049980335159L;
/*    */ 
/*    */   RequestException(String string)
/*    */   {
/* 26 */     super(string);
/*    */   }
/*    */ }

/* Location:           C:\ASV\Tools\jlani2_wordscompatible\bin\jlani2\
 * Qualified Name:     de.uni_leipzig.asv.toolbox.jLanI.kernel.RequestException
 * JD-Core Version:    0.6.0
 */